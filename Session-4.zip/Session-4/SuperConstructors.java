class X1{
	X1(){
		System.out.println("Class X1 constructor");
	}
	void display() {
		System.out.println("X1");
	}
}
class A1 extends X1{
	A1(int n){
		System.out.println("Class A1 constructor");
	}
	void display() {
		System.out.println("A1");
	}	
}

class B1 extends A1{
	B1(){
		super(10);
		System.out.println("Class B1 constructor");
	}
}

public class SuperConstructors {

	public static void main(String[] args) {
		B1 obj = new B1();
		obj.display();
	}

}
