class Employee 
{
	int empno;
	String name;
	float sal;
	
	void setDetails(){
	 empno = 102;
	 name = "Naveen";
	 sal=50000.5f;
	}
	void getDetails(){
     System.out.println(empno+" * "+name+" * "+sal);
	}
	public static void main(String[] args) 
	{
		Employee emp = new Employee();
		System.out.println(emp.empno+" | "+emp.name+" | "+emp.sal);

		//initialize instance variables with reference
		emp.empno=101;
		emp.name="Sunil";
		emp.sal=2500;
		System.out.println(emp.empno+" | "+emp.name+" | "+emp.sal);

		//initialize instance variables with method
		emp.setDetails();
		System.out.println(emp.empno+" | "+emp.name+" | "+emp.sal);

		emp.getDetails();
	}
}
