abstract class Shape{
	String color;
	public Shape(String color) {		
		this.color = color;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
	public abstract void area();
	abstract int addNum(int x, int y);
}

class Rectangle extends Shape{
	int length, breadth;
	public Rectangle(String color, int len, int bre) {
		super(color);
		this.length= len;
		this.breadth= bre;
	}
	@Override
	public void area() {
		System.out.println("Area of Rectangle = "+(this.length * this.breadth));		
	}
	@Override
	int addNum(int x, int y) {
		return x+y;
	}
}

public class AbsTest {
	public static void main(String[] args) {
		Shape s = null;
		s = new Rectangle("Red",5,3);
		System.out.println("Color = "+ s.getColor());
		s.setColor("Blue");
		System.out.println("Color = "+ s.getColor());
		s.area();
		
		System.out.println("Sum = "+s.addNum(10,20));
	}
}
