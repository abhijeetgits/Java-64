class Employee 
{
	int empno;
	String name;
	float sal;
	
	void setDetails(){
	 empno = 102;
	 name = "Naveen";
	 sal=50000.5f;
	}
	void getDetails(){
     System.out.println(empno+" * "+name+" * "+sal);
	}
} //class

class ObjectTest1
{
	public static void main(String[] args) 
	{
		Employee emp = new Employee();
		emp.getDetails();
		
		emp.setDetails();
		emp.getDetails();
	}
}
