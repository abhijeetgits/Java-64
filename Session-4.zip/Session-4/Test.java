class A{
	A(){}
	void calc(Object o){
		System.out.println(o.getClass().getName());
	}
}

class B extends A{
	B(){
		//super(this);
	}
	void calc(B obj){
		System.out.println(obj);
		super.calc(this);
	}
}


class Test 
{
	public static void main(String[] args) 
	{
		B obj =new B();
		obj.calc(obj);
	}
}
