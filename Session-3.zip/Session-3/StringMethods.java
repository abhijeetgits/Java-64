
public class StringMethods {

	public static void main(String[] args) {
		String str = "edureka";
		System.out.println("Size of String = "+ str.length()); //7
		System.out.println("char @ index 0 = "+ str.charAt(0)); //e
		System.out.println("index of \"e\" = "+ str.indexOf("e")); //0
		System.out.println("last index of \"e\" = "+ str.lastIndexOf("e")); //4
		System.out.println(str.toUpperCase()); //EDUREKA
		System.out.println(str.toLowerCase()); //edureka
		System.out.println(str.replace('e','*')); //*dur*ka
		System.out.println(str); //edureka
	}
}
