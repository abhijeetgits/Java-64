class A{
	int a=10,b=20;
	void display() {
		System.out.println("Inside class A");
		System.out.println(super.toString());
	}
}

class B extends A{
	int a=11,b=22;
	@Override //annotation
	void display() {
		System.out.println("Inside class B");
		super.display();
		System.out.println(a+" | "+b+" | "+super.a+" | "+super.b);
	}
}

public class OverridingMemsbers {

	public static void main(String[] args) {
		B obj = new B();
		System.out.println(obj.a+" | "+obj.b);
		obj.display();
	}
}