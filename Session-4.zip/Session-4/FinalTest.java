final class A{
	final int n; //blank final variable
	A(){
		n =10;
	}
	final void display(){} 
}
class B extends A{
	void display(){} //error: display() in B cannot override display() in A
}

class FinalTest 
{
	//final FinalTest(){} //error: modifier final not allowed here :: constructor cannot be final
	final int n = 15; //instance variable
	public static void main(String[] args) 
	{
		final int n = 10; //local variable
		System.out.println(n);
		//n = 10; //error: cannot assign a value to final variable n
		System.out.println(n);

		FinalTest obj = new FinalTest();
		System.out.println(obj.n);
		//obj.n=14; //error: cannot assign a value to final variable n
		System.out.println(obj.n);
	}
}
