
public class SBTest {

	public static void main(String[] args) {
		//StringBuffer sb = new StringBuffer();
		//StringBuffer sb = new StringBuffer(18);
		//StringBuffer sb = new StringBuffer("ABC");
		StringBuilder sb = new StringBuilder();
		
		System.out.println(sb+" |Size="+sb.length()+" |Capacity="+sb.capacity());
		
		sb.append("edureka limited ");
		System.out.println(sb+" |Size="+sb.length()+" |Capacity="+sb.capacity());
		
		sb.insert(0,"** ");
		System.out.println(sb+" |Size="+sb.length()+" |Capacity="+sb.capacity());
		
		sb.reverse();
		System.out.println(sb);
		sb.ensureCapacity(100);
		System.out.println(sb+" |Size="+sb.length()+" |Capacity="+sb.capacity());
	}
}
